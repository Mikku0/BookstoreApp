namespace BookstoreApp.Models;

public enum OrderStatus
{
    Oczekujące,
    Opłacone,
    Wysłane,
    Dostarczone,
    Anulowane
}
